const express = require("express");
const bodyParser = require('body-parser');
const cors = require("cors");
const dotenv = require("dotenv");
const session = require("express-session");
const signUpRouter = require("./src/routes/signUpRouter");
const loginRouter = require("./src/routes/loginRouter");
const logoutRouter = require("./src/routes/logoutRouter");
const mypageRouter = require("./src/routes/mypageRouter");
const resetPasswordRouter = require("./src/routes/resetPasswordRouter");
const passwordRouter = require('./src/routes/passwordRouter');
const adminRouter = require('./src/routes/adminRouter');
const naverRouter = require('./src/routes/naverRouter');
const youtubeRouter = require('./src/routes/youtubeRouter'); // 새로운 YouTube 라우터 불러오기
const mysql = require('mysql');
const instagramRouter = require('./src/routes/instagramRouter'); // 새로운 Instagram 라우터 불러오기
const twitterRouter = require('./src/routes/twitterRouter'); // 새로운 네이버 라우터 불러오기
const path = require('path'); // path 모듈 추가


// 환경 변수 설정
dotenv.config({ path: './src/routes/.env' });

const app = express();

// 데이터베이스 연결 설정
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

db.connect((err) => {
  if (err) {
    console.error('데이터베이스 연결 실패:', err);
  } else {
    console.log('데이터베이스 연결 성공');
  }
});

// CORS 설정
app.use(cors());

// JSON 파싱을 위한 미들웨어
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());

// 세션 설정
app.use(session({
  secret: process.env.SESSION_SECRET_KEY,
  resave: false,
  saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));
// EJS 설정
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/views'));

app.use("/sign", signUpRouter);
app.use("/login", loginRouter);
app.use("/logout", logoutRouter);
app.use("/mypage", mypageRouter);
app.use('/admin', adminRouter);
app.use("/", resetPasswordRouter);
app.use('/password', passwordRouter);
app.use('/naver', naverRouter); // 새로운 네이버 라우터 사용
app.use('/api', youtubeRouter); // 새로운 YouTube 라우터 사용
app.use('/instagram', instagramRouter); // 새로운 Instagram 라우터 사용
app.use('/twitter', twitterRouter); // 새로운 네이버 라우터 사용

// 라우트에서 뷰 렌더링
app.get('/', (req, res) => {
  res.render('login', { title: 'login' });
});

// 에러 핸들링 미들웨어 추가
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal Server Error', error: err.message });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});